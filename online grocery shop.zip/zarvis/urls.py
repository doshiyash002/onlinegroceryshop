from django.contrib import admin
from django.urls import path
from zarvis import views

urlpatterns = [
    path("",views.index,name='zarvis'),
    path("about",views.about,name='about'),
    path("services",views.services,name='services'),
    path("contact",views.contact,name='contact'),
]